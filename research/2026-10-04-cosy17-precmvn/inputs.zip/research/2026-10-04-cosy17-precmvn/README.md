# Cosy17 native PRE-CMVN training inputs

This package contains 17 unchanged native feature arrays (1,108,800 bytes), their exact audio/feature identities, and human lexical labels. It contains no source audio or model weights. MANIFEST.json gives the fixed order and reuses the original 32 prepared inputs by their existing immutable repository commit; those 32 arrays are not copied here.

Features are little-endian float32, 693 valid rows × 400, before CMVN. Apply the original model CMVN exactly once at model entry. No normalization, augmentation, resampling or extra model inference was applied to these saved arrays.

The two mismatched repeated-phrase generations use the confirmed actual words 小窝 and 小屋 as two-token CTC targets. Do not restore their planned repeated phrases or assign empty targets. All targets are explicit nonblank lexical sequences. Inaudible and development clips are excluded. Words have been transcribed, but word-tail boundaries were not annotated. Stock voices and the baseline examples were already exposed; this is not a fresh-speaker or heldout qualification set.

Generation code/config and audio hashes are supplied for provenance. Temporary Actions artifacts are not a permanent source-audio archive; source WAVs are not distributed in this package and have no permanent public location asserted here. The exact saved feature bytes can be pinned at this package's repository commit for training reproducibility.

No new license is granted by this package, and commercial clearance of generated output is not established. Preserve applicable source notices; model-license records alone are not a claim of complete generated-output rights. This technical package does not qualify real-world false-reject/false-activation rates or device performance.
